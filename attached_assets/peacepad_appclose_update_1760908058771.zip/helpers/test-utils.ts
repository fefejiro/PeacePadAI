
export const generateRandomName = () => 'Parent_' + Math.random().toString(36).substring(2, 8);
